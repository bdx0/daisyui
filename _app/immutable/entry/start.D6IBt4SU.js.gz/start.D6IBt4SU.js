import{a as t}from"../chunks/entry.BjbkgdU0.js";export{t as start};
