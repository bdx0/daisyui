import{a as t}from"../chunks/entry.BooVtJ_V.js";export{t as start};
