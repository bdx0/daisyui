import{a as t}from"../chunks/entry.BpKALOw3.js";export{t as start};
