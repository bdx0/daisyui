import{a as t}from"../chunks/entry.CK3w_U_p.js";export{t as start};
