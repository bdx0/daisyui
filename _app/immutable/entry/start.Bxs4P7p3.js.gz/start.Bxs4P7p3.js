import{a as t}from"../chunks/entry.C0df1Lpv.js";export{t as start};
